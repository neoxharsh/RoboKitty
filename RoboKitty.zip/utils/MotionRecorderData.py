class MotionRecorderData:

    def __init__(self):
        self.data = []
        self.motionName = ""